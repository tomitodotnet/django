from django.db import models
from django.utils import timezone
from datetime import date

# Create your models here.

class Persona(models.Model):
    nombre = models.CharField(max_length=30, default=' ')
    apellido = models.CharField(max_length=30, default='')
    cedula = models.CharField(max_length=10, default='')
    correo = models.CharField(max_length=50, null = True, blank=True)
    telefono = models.CharField(max_length=30 , null = True, blank=True)
    user = models.OneToOneField('auth.user', on_delete=models.PROTECT, related_name='user', default='')

class Concierto(models.Model):
    artista = models.CharField(max_length=50, default=' ')
    nombre = models.CharField(max_length=200, default='')
    cantidad = models.FloatField(default=600)
    fecha_show = models.DateTimeField(default=timezone.now)
    precio = models.FloatField(default=30)

class CompraTicket(models.Model):
    fecha = models.DateTimeField(default=timezone.now)
    persona = models.ForeignKey('Persona', on_delete = models.PROTECT, related_name= 'persona')
    tickets = models.FloatField(default=000)
    concierto = models.ForeignKey('Concierto', on_delete = models.PROTECT, related_name= 'concierto')
    esta_anulada = models.BooleanField(default=True)
    total = models.FloatField(default=0)

class Pago(models.Model):
    fecha_creacion = models.DateTimeField(default=timezone.now)
    compra = models.ForeignKey('CompraTicket', on_delete = models.PROTECT, related_name= 'compraticket')
    abono = models.FloatField(default=0, null = True ) 
    
    
    