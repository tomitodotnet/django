from django.shortcuts import render, redirect
import datetime
from django.shortcuts import HttpResponse
from django.views.generic import TemplateView
from .models import Concierto
from .models import Persona
from .models import CompraTicket

from django.contrib import messages
from django.contrib.auth import login, logout, authenticate

from .forms import RegistroForm, LoginForm

# Create your views here.
def getInfoConciertoById(request, id_concierto):
    concierto = Concierto.objects.get(id=id_concierto)
    return render(request, "concierto.html", {'Artista': concierto.artista, 'Concierto': concierto.nombre , 'Precio': concierto.precio , 'Cantidad': concierto.cantidad , 'Fecha': concierto.fecha_show , 'Conciertoid': concierto.id  })

def getListadoConciertos(request):
    conciertos = Concierto.objects.all()
    listado_conciertos = []
    for concierto in conciertos:
        listado_conciertos.append((concierto.id, concierto.nombre))
    return render(request, "conciertos.html", {'listado': listado_conciertos})

def getMisConciertos(request):
    user =request.user.id
    persona = Persona.objects.get(user__id=user)
    personaid = persona.id
    compras = CompraTicket.objects.all()
    listado_conciertos = []
    for compra in compras:
        if compra.esta_anulada == False and compra.persona.id == personaid:
          listado_conciertos.append((compra.concierto.id, compra.concierto.nombre))
    return render(request, "misconciertos.html", {'listado': listado_conciertos})

def getMiConciertoById(request, id_concierto):
    concierto = Concierto.objects.get(id=id_concierto)
    return render(request, "miconcierto.html", {'Artista': concierto.artista, 'Concierto': concierto.nombre , 'Precio': concierto.precio , 'Cantidad': concierto.cantidad , 'Fecha': concierto.fecha_show  , 'Conciertoid': concierto.id})


def reservarConcierto(request, id_concierto):
 if request.method == 'POST':
   user =request.user.id
   persona = Persona.objects.get(user__id=user)
   concierto = Concierto.objects.get(id=id_concierto)

   #cantidad = request.GET['tickets.value'] 

   new_reserva = CompraTicket(concierto=concierto, persona=persona, tickets = 1, esta_anulada=False)
   new_reserva.save()

   concierto.cantidad = concierto.cantidad - 1 # cantidad
   concierto.save() 

   #horario.esta_disponible = False
   #horario.save()
   print (user)
   print (new_reserva)
   messages.info(request, 'Se ha realizado su compra')
   return redirect(f'/getInfoConciertoById/{concierto.id}')

def anularConcierto(request, id_concierto):
 if request.method == 'POST':
   user =request.user.id
   persona = Persona.objects.get(user__id=user)
   concierto = Concierto.objects.get(id=id_concierto)
   
   compra = CompraTicket.objects.get(persona__id=persona.id , concierto__id=id_concierto)
   compra.esta_anulada = True
   compra.save()

   concierto.cantidad = concierto.cantidad + compra.tickets
   concierto.save() 
    
   print (user)
   print (compra)
   messages.info(request, 'Se ha realizado su transaccion de cancelacion')
   return redirect(f'/misconciertos/')


class MainView(TemplateView):
    template_name="main.html"

def getInfoPersonaById(request ,id_persona):
    #obtener Persona por su id
    persona = Persona.objects.get(id=id_persona)
    result = f"Persona: {persona.nombre}, Descripción: {persona.apellido} y tu correo es {persona.correo} ."
    return HttpResponse(result)


def registro_request(request):
 if request.method == 'POST':
   form = RegistroForm(request.POST)
   if form.is_valid():
     user = form.save()
     login(request, user)
     messages.success(request, 'Se ha registrado exitosamente')
     return redirect("landing")
   messages.error(request, 'Información no válida')
 # Método no válido, retorna formulario vacío
 form = RegistroForm()
 return render(request=request,        
               template_name='registro.html', 
               context={'registro_form': form})

def login_request(request):
 if request.method == 'POST':
   form = LoginForm(request, data=request.POST)
   if form.is_valid():
     username = form.cleaned_data.get('username')
     password = form.cleaned_data.get('password')
     user = authenticate(username=username, password=password)
     if user is not None:
       login(request, user)
       messages.info(request, f'Ha iniciado sesión como: {username}')
       return redirect("landing")
     messages.error(request, 'Credenciales incorrectas')
   messages.error(request, 'Credenciales incorrectas')
 # Método no válido, retorna formulario vacío
 form = LoginForm()
 return render(request=request,
               template_name='login.html',
               context={'login_form': form})

def logout_request(request):
 logout(request)
 messages.info(request, "Has cerrado sesión")
 return redirect("login")



