from django.contrib import admin

# Register your models here.

from .models import Persona, Concierto,  CompraTicket, Pago

admin.site.register (Persona)
admin.site.register (Concierto)
admin.site.register (CompraTicket)
admin.site.register (Pago)
